export default {
  labels: ["TBD", "TBD", "TBD", "TBD", "TBD"],
  datasets: { label: "Runs", data: [0, 0, 0, 0, 0, 0] },
};
