export default {
  labels: ["TBD", "TBD", "TBD", "TBD", "TBD"],
  datasets: { label: "Wickets", data: [0, 0, 0, 0, 0, 0] },
};
