export default {
  labels: ["Ajay", "Alok", "Anjali", "Shriyam", "Suraj", "Utkarsh"],
  datasets: { label: "Points", data: [0, 0, 0, 0, 0, 0, 0] },
};
