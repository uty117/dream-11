export default {
  labels: ["TBD", "TBD", "TBD", "TBD", "TBD"],
  datasets: { label: "Points", data: [0, 0, 0, 0, 0, 0] },
};
