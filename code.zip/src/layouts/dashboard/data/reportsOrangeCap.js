export default {
  labels: ["Ajay", "Alok", "Anjali", "Shriyam", "Suraj", "Utkarsh"],
  datasets: { label: "Wins", data: [0, 0, 0, 0, 0, 0, 0] },
};
